package com.privateofflineai.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.google.android.gms.tasks.Tasks
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("owner_state", Context.MODE_PRIVATE) }
    private val worker = Executors.newSingleThreadExecutor()
    private val ocr by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val PICK_FILES = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)

        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true
        }
        web.addJavascriptInterface(SecurityBridge(), "AndroidSecurity")
        web.addJavascriptInterface(FileBridge(), "AndroidFiles")
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        worker.shutdownNow()
        ocr.close()
        super.onDestroy()
    }

    private fun canUseStrongBiometric(): Boolean =
        BiometricManager.from(this).canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        ) == BiometricManager.BIOMETRIC_SUCCESS

    private fun jsQuote(value: String): String {
        val clipped = value.take(220_000)
        return JSONObject.quote(clipped)
    }

    private fun sendOwner(success: Boolean, message: String) {
        val call = "window.androidOwnerResult($success, ${jsQuote(message)})"
        web.post { web.evaluateJavascript(call, null) }
    }

    private fun sendFile(name: String, text: String, ok: Boolean, message: String) {
        val call = "window.nativeFileResult(${jsQuote(name)}, ${jsQuote(text)}, $ok, ${jsQuote(message)})"
        web.post { web.evaluateJavascript(call, null) }
    }

    private fun biometric(title: String, subtitle: String, description: String, onSuccess: () -> Unit) {
        if (!canUseStrongBiometric()) {
            sendOwner(false, "Strong biometric authentication is unavailable. Set up a fingerprint in Android Settings first.")
            return
        }
        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onSuccess()
                override fun onAuthenticationFailed() = sendOwner(false, "Fingerprint not recognized. Try again.")
                override fun onAuthenticationError(code: Int, message: CharSequence) = sendOwner(false, message.toString())
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setDescription(description)
            .setNegativeButtonText("Cancel")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()
        prompt.authenticate(info)
    }

    inner class SecurityBridge {
        @JavascriptInterface fun ownerExists(): Boolean = prefs.getBoolean("owner_created", false)

        @JavascriptInterface fun createOwner(name: String) {
            runOnUiThread {
                if (ownerExists()) {
                    sendOwner(false, "An Owner already exists. Only one Owner can be created.")
                    return@runOnUiThread
                }
                biometric(
                    "Create Owner",
                    "Verify your fingerprint",
                    "Android verifies the biometric. The app never receives your fingerprint."
                ) {
                    prefs.edit().putBoolean("owner_created", true).putString("owner_name", name).apply()
                    sendOwner(true, "Owner created successfully. The Owner can be created only once.")
                }
            }
        }

        @JavascriptInterface fun authenticateOwner() {
            runOnUiThread {
                if (!ownerExists()) {
                    sendOwner(false, "No Owner exists. Create the Owner first.")
                    return@runOnUiThread
                }
                biometric(
                    "Owner / Admin",
                    "Verify your fingerprint",
                    "Only the registered Owner can open administration."
                ) { sendOwner(true, "Owner fingerprint verified.") }
            }
        }

        @JavascriptInterface fun deleteAllWithOwnerFingerprint() {
            runOnUiThread {
                if (!ownerExists()) {
                    sendOwner(false, "No Owner exists.")
                    return@runOnUiThread
                }
                biometric(
                    "Permanent deletion",
                    "Verify Owner fingerprint",
                    "This permanently resets the local Owner and AI data."
                ) {
                    prefs.edit().clear().apply()
                    web.post { web.evaluateJavascript("window.nativeDeleteAllConfirmed()", null) }
                }
            }
        }
    }

    inner class FileBridge {
        @JavascriptInterface fun openFilePicker() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                startActivityForResult(intent, PICK_FILES)
            }
        }
    }

    @Deprecated("Use Activity Result API in a future refactor")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_FILES || resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.data?.let { uris.add(it) }
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
        for (uri in uris.distinct()) processUri(uri)
    }

    private fun processUri(uri: Uri) {
        worker.execute {
            val name = displayName(uri)
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            try {
                val mime = contentResolver.getType(uri).orEmpty()
                val lower = name.lowercase()
                val result = when {
                    lower.endsWith(".pdf") || mime == "application/pdf" -> extractPdf(uri)
                    lower.endsWith(".docx") || mime == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" -> extractDocx(uri)
                    lower.endsWith(".txt") || lower.endsWith(".csv") || lower.endsWith(".json") ||
                    lower.endsWith(".md") || lower.endsWith(".markdown") || lower.endsWith(".html") ||
                    lower.endsWith(".htm") || lower.endsWith(".xml") -> extractPlain(uri)
                    mime.startsWith("image/") || lower.matches(Regex(".*\\.(png|jpg|jpeg|webp|bmp|heic)$")) -> extractImage(uri)
                    else -> throw IllegalArgumentException("Unsupported file type: $name")
                }
                sendFile(name, result, true, "Read successfully")
            } catch (e: Exception) {
                sendFile(name, "", false, "Could not read $name: ${e.message ?: "unknown error"}")
            }
        }
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return uri.lastPathSegment ?: "document"
    }

    private fun extractPlain(uri: Uri): String =
        contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            ?: throw IllegalArgumentException("Unable to open file")

    private fun extractDocx(uri: Uri): String {
        val sb = StringBuilder()
        contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                while (true) {
                    val e = zip.nextEntry ?: break
                    if (e.name == "word/document.xml") {
                        val xml = zip.readBytes().toString(Charsets.UTF_8)
                        val clean = xml
                            .replace(Regex("<w:tab[^>]*/>"), "\t")
                            .replace(Regex("<w:br[^>]*/>"), "\n")
                            .replace(Regex("</w:p>"), "\n\n")
                            .replace(Regex("<[^>]+>"), "")
                            .replace("&amp;", "&").replace("&lt;", "<")
                            .replace("&gt;", ">").replace("&quot;", "\"")
                            .replace("&#39;", "'")
                        sb.append(clean)
                    }
                }
            }
        } ?: throw IllegalArgumentException("Unable to open DOCX")
        return sb.toString().trim()
    }

    private fun extractPdf(uri: Uri): String {
        val temp = File.createTempFile("doc_", ".pdf", cacheDir)
        contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(temp).use { output -> input.copyTo(output) }
        } ?: throw IllegalArgumentException("Unable to open PDF")

        var text = ""
        PDDocument.load(temp).use { doc ->
            val stripper = PDFTextStripper()
            stripper.sortByPosition = true
            text = stripper.getText(doc)
        }

        if (text.trim().length < 20) {
            text = ocrPdfPages(temp)
        }
        temp.delete()
        return text.trim()
    }

    private fun ocrPdfPages(file: File): String {
        val sb = StringBuilder()
        android.graphics.pdf.PdfRenderer(android.os.ParcelFileDescriptor.open(
            file, android.os.ParcelFileDescriptor.MODE_READ_ONLY
        )).use { renderer ->
            for (i in 0 until renderer.pageCount) {
                renderer.openPage(i).use { page ->
                    val scale = 2.0f
                    val bitmap = Bitmap.createBitmap(
                        (page.width * scale).toInt(),
                        (page.height * scale).toInt(),
                        Bitmap.Config.ARGB_8888
                    )
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    sb.append("\n--- PDF page ${i + 1} ---\n")
                    sb.append(ocrBitmap(bitmap))
                    bitmap.recycle()
                }
            }
        }
        return sb.toString()
    }

    private fun extractImage(uri: Uri): String {
        val bitmap = android.graphics.BitmapFactory.decodeStream(contentResolver.openInputStream(uri))
            ?: throw IllegalArgumentException("Unable to decode image")
        val text = ocrBitmap(bitmap)
        bitmap.recycle()
        return text
    }

    private fun ocrBitmap(bitmap: Bitmap): String {
        val image = InputImage.fromBitmap(bitmap, 0)
        val result = Tasks.await(ocr.process(image))
        return result.text
    }
}
