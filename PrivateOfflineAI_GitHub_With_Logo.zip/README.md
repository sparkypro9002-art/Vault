# Private Offline AI — GitHub APK Build

## Phone-only build

1. Extract this project ZIP.
2. Create a GitHub repository named `PrivateOfflineAI`.
3. Upload the **contents** of this folder to the repository root.
4. Open **Actions**.
5. Select **Build Private Offline AI APK**.
6. Tap **Run workflow** if it did not start automatically.
7. When it finishes, open the workflow run and download the artifact **PrivateOfflineAI-debug-apk**.
8. Extract the artifact and install `app-debug.apk`.

No Android Studio or computer is required.

The app includes:
- Private Offline AI interface and app logo
- Native Android biometric owner authentication
- Local IndexedDB memory
- PDF/DOCX/text/image reading
- Bundled ML Kit OCR
- PDF text extraction with PdfBox-Android
- GitHub Actions APK build

The GitHub workflow installs Gradle directly, so the project does not require a Gradle wrapper.

IMPORTANT: Do not put passwords, API keys, signing keys, or personal data in the GitHub repository.
